package com.example.demo;

import java.nio.file.Files;
import java.nio.file.Paths;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.github.opendevl.JFlat;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args)throws Exception {
		SpringApplication.run(DemoApplication.class, args);
		
		String jsonString = new String(Files.readAllBytes(Paths.get("src/main/resources/Mehul.json")));
		JFlat flatMe = new JFlat(jsonString);
		flatMe
		    .json2Sheet()
		    .headerSeparator("/")
		    .write2csv("src/main/resources/orderLines1.csv");
	
	
	}
}
