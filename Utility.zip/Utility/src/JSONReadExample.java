
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.opencsv.CSVWriter;

public class JSONReadExample {
	
	static List<String> keys = new ArrayList<String>();
	static List<String> values = new ArrayList<String>();
	static String[] jsonKeys;
	
	public static Object readJsonSimpleDemo(String filename) throws Exception {  
	    FileReader reader = new FileReader(filename);
	    JSONParser jsonParser = new JSONParser();
	    return jsonParser.parse(reader);
	}
	
	
	public static void printJSON(JSONObject jsonObj) {
	    for (Object keyObj : jsonObj.keySet()) {
	        String key = (String)keyObj;
	        Object valObj = jsonObj.get(key);
	        if (valObj instanceof JSONArray) {
	            // call printJSON on nested object
	        	
	        	JSONArray arr =  (JSONArray) valObj;
	        	for(int i=0;i<arr.size();i++){
		        	JSONObject objj= (JSONObject) arr.get(i);
		            printJSON((JSONObject)objj);
	            }
	        } else if (valObj instanceof JSONObject) {
	            // call printJSON on nested object
	            printJSON((JSONObject)valObj);
	        } else {
	            // print key-value pair
	            System.out.println("key :: "+key);
	            System.out.println("value :: "+valObj.toString());
	            
	            keys.add(key);
		        values.add(valObj.toString());
	        }
	    }
	}
	
	 public static void main(String[] args) throws Exception      { 
		// parsing file "JSONExample.json" 
	        JSONObject obj = (JSONObject) readJsonSimpleDemo("data/JSONExample.json");
	        printJSON( obj);
	       	        
	        // getting firstName and lastName 
	       /* String firstName = (String) obj.get("firstName"); 
	        String lastName = (String) obj.get("lastName"); 
	        System.out.println(firstName); 
	        System.out.println(lastName);
	        
	        rows.add(firstName);
	        rows.add(lastName);*/
	        
	       
	        /*Set keys = obj.keySet();
            Iterator a = keys.iterator();
            while(a.hasNext()) {
            	String key = (String)a.next();
                
            	// loop to get the dynamic key
                String value = (String) obj.get(key).toString();
                
                System.out.println("key : "+key);
                System.out.println(" value :"+value);
            }*/
            
            
            
	        
//	        jsonKeys = org.json.JSONObject.getNames(obj);
//	        System.out.println("\n"+jsonKeys.toString());
//	        // iterate over them
//	        for (String key : jsonKeys)
//	        {
//	            // retrieve the values
//	            Object value = obj.get(key);
//	            // if you just have strings:
//	            String values = (String) obj.get(key);
//	            System.out.println("\n"+values);
//	            keys.add(values);
//	        }
//	        
	        
	        
	       /* // getting age 
	        long age = (long) obj.get("age"); 
	         	        // getting address 
	        Map address = ((Map)obj.get("address")); 
	          
	        // iterating address Map 
	        Iterator<Map.Entry> itr1 = address.entrySet().iterator(); 
	        while (itr1.hasNext()) { 
	            Map.Entry pair = itr1.next(); 
	            System.out.println(pair.getKey() + " : " + pair.getValue()); 
	        } 
	          
	        // getting phoneNumbers 
	        JSONArray ja = (JSONArray) obj.get("phoneNumbers"); 
	          
	        // iterating phoneNumbers 
	        Iterator itr2 = ja.iterator(); 
	        while (itr2.hasNext())  
	        { 
	            itr1 = ((Map) itr2.next()).entrySet().iterator(); 
	            while (itr1.hasNext()) { 
	                Map.Entry pair = itr1.next(); 
	                System.out.println(pair.getKey() + " : " + pair.getValue()); 
	            } 
	        }*/ 
	        
	        CSVWriterr();
	    } 
	 
	 
	 @SuppressWarnings("unused")
		private static void CSVWriterr() throws IOException {
			
		 CSVWriter csvWriter = new CSVWriter(new FileWriter("data/JSONRead.csv"));
//	     csvWriter.writeNext(new String[]{"Policy Number", "MemberId"});
	    
	     String[] strKeys = new String[keys.size()];
	     String[] strValues = new String[values.size()];
	     for(int i=0;i<keys.size();i++){
	    	 strKeys[i]=keys.get(i);	    	 
	     }
	     
	     for(int i=0;i<values.size();i++){
	    	 strValues[i]=values.get(i);	    	 
	     }
	     
	     csvWriter.writeNext(strKeys);
	     csvWriter.writeNext(strValues);
//		 csvWriter.writeAll(rows);
		 csvWriter.close();
		}
		
	 
	 
	} 