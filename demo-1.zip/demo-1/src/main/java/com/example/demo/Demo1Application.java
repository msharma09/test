package com.example.demo;



import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

import org.apache.crunch.types.orc.OrcUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.io.orc.OrcFile;
import org.apache.hadoop.hive.ql.io.orc.OrcStruct;
import org.apache.hadoop.hive.ql.io.orc.Writer;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.typeinfo.TypeInfo;
import org.apache.hadoop.hive.serde2.typeinfo.TypeInfoUtils;
import org.apache.hadoop.io.Text;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class Demo1Application {

	public static void main(String[] args)throws Exception {
		SpringApplication.run(Demo1Application.class, args);
		System.setProperty("hadoop.home.dir", "C:\\Users\\this pc\\Downloads\\hadoop\\hadoop_common");
	

		  InputStream is = new FileInputStream("src/main/resources/Mehul.json"); 
		  BufferedReader buf = new BufferedReader(new InputStreamReader(is)); 
		  String line = buf.readLine(); 
		  StringBuilder sb = new StringBuilder(); 
		  while(line != null)
		  { 
			  sb.append(line).append("\n"); 
			  line = buf.readLine(); 
			  } 
		  String fileAsString = sb.toString(); 
		  System.out.println(fileAsString);

		 
		  
		  
		//String tsvString = "text_string\t1\t2\t3\t123.4\t123.45";
		 // String tsvString = fileAsString;
		String typeStr = "struct<a:string>";
		TypeInfo typeInfo = TypeInfoUtils.getTypeInfoFromTypeString(typeStr);
		ObjectInspector inspector = OrcStruct.createObjectInspector(typeInfo);

		//String[] inputTokens = tsvString.split("\\t");
		String inputTokens = fileAsString;
		System.out.println(inputTokens);
		OrcStruct orcLine = OrcUtils.createOrcStruct(
				typeInfo,
				new Text(inputTokens));
		Configuration conf = new Configuration();
		Path tempPath = new Path("src/main/resources/testing.orc");
		Writer writer = OrcFile.createWriter(tempPath, OrcFile.writerOptions(conf).inspector(inspector).stripeSize(100000).bufferSize(10000));
		//System.out.println(orcLine);
		writer.addRow(orcLine);
		writer.close();
	

	}

}
